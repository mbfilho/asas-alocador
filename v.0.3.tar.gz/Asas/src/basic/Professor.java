package basic;

import java.io.Serializable;


public class Professor implements NamedEntity, Serializable{
	private String name;
	
	public Professor(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
}
