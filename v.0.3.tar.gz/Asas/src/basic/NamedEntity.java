package basic;

public interface NamedEntity {
	public String getName();
}
