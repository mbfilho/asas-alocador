package data;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;

import basic.DataValidation;
import basic.Professor;

import exceptions.InvalidInputException;

public class SimpleProfessorReader implements DataReader<Professor> {
	private String fileName = "professors.in";

	public DataValidation<Repository<Professor>> read() throws InvalidInputException {
		Vector<Professor> readed = new Vector<Professor>();
		
		try {
			Scanner sc = new Scanner(new File(fileName));
			while(sc.hasNext()) readed.add(new Professor(sc.nextLine()));
			sc.close();
		} catch (FileNotFoundException e) {
			throw new InvalidInputException("Arquivo \"" + fileName + "\" não encontrado.");
		}
			
		return new DataValidation(new SimpleRepository<Professor>(readed));
	}
}
