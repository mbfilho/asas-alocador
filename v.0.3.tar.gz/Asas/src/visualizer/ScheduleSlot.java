package visualizer;
import basic.Class;

public class ScheduleSlot {
	Class theClass;
	
	public ScheduleSlot(Class theClass){
		this.theClass = theClass;
	}
	
}
