package visualizer;

public class GroupByClassroom extends SimpleGroup{

	public String getGroupArg(ScheduleSlot scheduled) {
		return scheduled.theClass.getClassroom().getName(); 
	}

	public boolean canBeGrouped(ScheduleSlot scheduled) {
		return scheduled.theClass.getClassroom() != null;
	}
}
