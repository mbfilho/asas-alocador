package visualizer;

import htmlGenerator.PageWithTables;

import java.util.Vector;

import statePersistence.StateService;
import basic.Class;

public class VisualizerService {
	
	public String groupByClassroom(){
		Schedule schedule = new Schedule();
		for(Class c : StateService.getInstance().getCurrentState().classes.all()){
			schedule.addClass(c);
		}
		return generateHtml(new GroupByClassroom().makeGroup(schedule), "Sala: ");
	}
	
	private String generateHtml(Vector<Group> groups, String title){
		PageWithTables page = new PageWithTables();
		for(Group group: groups)
			page.addTable(group.generateHtmlTable(title));
		
		return page.generateHtml();
	}
}
