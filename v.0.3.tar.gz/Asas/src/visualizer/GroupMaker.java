package visualizer;

import java.util.Vector;

public interface GroupMaker {
	Vector<Group> makeGroup(Schedule schedule);
}
