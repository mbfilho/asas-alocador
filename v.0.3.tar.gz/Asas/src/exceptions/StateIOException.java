package exceptions;

public class StateIOException extends Exception {

	public StateIOException(String string, Exception ex) {
		super(string, ex);
	}

}
