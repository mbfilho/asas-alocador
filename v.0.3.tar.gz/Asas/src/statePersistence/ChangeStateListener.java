package statePersistence;

public interface ChangeStateListener{
	public void onChangeState(State loaded);
}
