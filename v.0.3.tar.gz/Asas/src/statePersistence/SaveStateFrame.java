package statePersistence;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import exceptions.StateIOException;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JPanel;
import java.awt.GridBagLayout;
import java.util.Date;

import javax.swing.JTextField;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;

public class SaveStateFrame extends ChooseStateFrame{
	private static final long serialVersionUID = 8910633735786246632L;
	private JTextField nameText;
	
	public SaveStateFrame() {
		super();
		setEditable(true);
		setTitle("Salvar Estado Atual");
		loadButton.setText("Salvar");
		GridBagLayout gridBagLayout = (GridBagLayout) getContentPane().getLayout();
		gridBagLayout.rowHeights = new int[]{0, 170, 26, 140, 0, 121, 0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0};
		gridBagLayout.columnWeights = new double[]{1.0};
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 5, 0);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 3;
		getContentPane().add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] {76, 133};
		gbl_panel.rowHeights = new int[] {26};
		gbl_panel.columnWeights = new double[]{0.0, 1.0};
		gbl_panel.rowWeights = new double[]{0.0};
		panel.setLayout(gbl_panel);
		
		JLabel lblNome = new JLabel("Nome");
		GridBagConstraints gbc_lblNome = new GridBagConstraints();
		gbc_lblNome.fill = GridBagConstraints.BOTH;
		gbc_lblNome.insets = new Insets(0, 0, 0, 5);
		gbc_lblNome.gridx = 0;
		gbc_lblNome.gridy = 0;
		panel.add(lblNome, gbc_lblNome);
		
		String suggested = new Date(System.currentTimeMillis()).toString().replace(" ", "-");
		nameText = new JTextField(suggested);
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.fill = GridBagConstraints.BOTH;
		gbc_textField.gridx = 1;
		gbc_textField.gridy = 0;
		panel.add(nameText, gbc_textField);
		nameText.setColumns(10);
		getContentPane().setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{nameText, descTextScrollPanel, listScrollPane, draftCheck}));
		setVisible(true);
	}

	protected String getNameText(){
		return nameText.getText();
	}
	
	protected void onOkButton() {
		try {
			StateService service = StateService.getInstance();
			if(service.hasValidState()){
				State s = service.getCurrentState();
				s.setStateDescription(getNameText(), getDescriptionText(), getDraftCheckValue());
				service.saveNewState(s);
				setVisible(true);
			}else{
				JOptionPane.showMessageDialog(this, "Nenhum estado válido foi carregado.");
			}
		} catch (StateIOException e) {
			JOptionPane.showMessageDialog(this, "Ocorreu um erro ao tentar salvar o estado atual.");
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		new SaveStateFrame();
	}

}
