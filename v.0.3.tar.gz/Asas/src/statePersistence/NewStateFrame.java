package statePersistence;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import edit.NamedPair;
import exceptions.StateIOException;

public class NewStateFrame extends SaveStateFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewStateFrame frame = new NewStateFrame(new ChangeStateListener() {
						public void onChangeState(State loaded) {
						}
					});
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	private ChangeStateListener creationListener;
	
	public NewStateFrame(ChangeStateListener creationListener) {
		this.creationListener = creationListener;
		loadButton.setText("Criar");
		setResizable(false);
		getStateListLabel().setText("Escolha um estado base:");
		setTitle("Criar novo estado");
		setBounds(100, 100, 264, 497);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	protected void onOkButton() {
		if(getSelected() == null) return;
		StateService stateService = StateService.getInstance();
		if(stateService.existName(getNameText())){
			JOptionPane.showMessageDialog(this, "Já existe um estado salvo com o nome \"" + getName() + "\".\nPor favor escolha outro", "Nome já existente", JOptionPane.ERROR_MESSAGE);
		}else{
			State base;
			try {
				base = stateService.loadState(getSelected().data);
				base.setStateDescription(getNameText(), getDescriptionText(), getDraftCheckValue());
				stateService.saveNewState(base);
				stateService.setCurrentState(base.description);
				setVisible(false);
				creationListener.onChangeState(stateService.getCurrentState());
			} catch (StateIOException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
				e1.printStackTrace();
			}
		}
	}

}
